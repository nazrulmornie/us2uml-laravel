<?php $__env->startSection('content'); ?>
<div class="container-md container-fluid py-5">
  <h1>User Stories and UML Diagram Submission</h1>
  <div class="table-responsive mt-3">
    <table class="table align-middle">
      <thead class="table-dark">
        <tr>
          <th scope="col">#</th>
          <th scope="col">Upload Time</th>
          <th scope="col">Project Name</th>
          <th scope="col">UML Diagram</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $uml; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uml): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row">1</th>
            <td> <?php echo e($uml->created_at->diffForHumans()); ?> </td>
            <td> <?php echo e($uml->project_name); ?> </td>
            <td>
                <img class="img-fluid img-thumbnail" src="<?php echo e(asset('storage/images/'.$uml->image)); ?>" height="100px" width="100px">
            </td>
            <td>
                <a href="{% url 'submission_detail' uml_diagram_id=diagram.id %}" role="button" class="btn btn-primary">
                    Details
                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\us2uml\us2umlgm\resources\views/submission_detail.blade.php ENDPATH**/ ?>