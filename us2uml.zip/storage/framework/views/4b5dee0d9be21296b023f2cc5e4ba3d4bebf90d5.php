<?php echo e($slot); ?>

<?php /**PATH C:\projects\us2uml\us2umlgm\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>