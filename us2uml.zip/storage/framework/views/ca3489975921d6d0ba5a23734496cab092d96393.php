<?php $__env->startSection('title'); ?> Submission Details <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container position-relative py-5 mb-3">
    <h1 class="text-center text-uppercase">
        <a href="<?php echo e(route('add-uml.edit', $uml->id)); ?>"><?php echo e($uml->project_name); ?></a>
    </h1>
    <div class="container-sm">
        <figure class="text-center">
            <a href="<?php echo e(route('add-uml.edit', $uml->id)); ?>">
                <img src="<?php echo e(asset('storage/images/'.$uml->image)); ?>" class="img-thumbnail rounded mx-auto d-block mt-3">
            </a>
            <figcaption>Click the diagram to update</figcaption>
        </figure>
    </div>

    <hr>
    <h1 class="text-center">User Stories</h1>

    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
        <strong><?php echo e(session('success')); ?></strong>
    </div>
    <?php endif; ?>

    <?php if(session('danger')): ?>
    <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
        <strong><?php echo e(session('danger')); ?></strong>
    </div>
    <?php endif; ?>

    <div class="container-fluid">
        <div class="table-responsive-md">
            <table class="table table-striped mb-4">
                <thead>
                    <tr class="text-center">
                        <th scope="col">#</th>
                        <th scope="col">User Story</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $userStory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e(++$key); ?></th>
                        <td><?php echo e($story->user_story); ?></td>
                        <td><a href="<?php echo e(route('submit.edit', $story->id)); ?>" role="button" class="btn btn-warning mb-2" style="width: 100%">Edit</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <hr>
        <div class="d-flex justify-content-center">
            <a href="<?php echo e(route('add-stories.edit', $uml->id )); ?>" class="btn btn-success mb-3 me-auto p-2 bd-highlight" style="width: 35%">Add More User Story</a>
            <a href="<?php echo e(route('submit.index')); ?>" class="btn btn-primary mb-3 p-2 bd-highlight" style="width: 35%">Back</a>
        </div>
    </div>
</div>

<script type="text/javascript">

    $(document).ready(function () {

    window.setTimeout(function() {
        $(".alert").fadeTo(1000, 0).slideUp(1000, function(){
            $(this).remove();
        });
    }, 5000);

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\us2uml\us2umlgm\resources\views/uml/uml_details.blade.php ENDPATH**/ ?>