<?php $__env->startSection('title'); ?> No submissions <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column justify-content-center align-items-center vh-100">
        <div class="p-2">
            <h1>No submission yet</h1>
        </div>
        <div class="p-2">
            <a href="<?php echo e(route('submit.create')); ?>" class="btn btn-secondary">Make new submission</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\us2uml\us2umlgm\resources\views/no_submission.blade.php ENDPATH**/ ?>