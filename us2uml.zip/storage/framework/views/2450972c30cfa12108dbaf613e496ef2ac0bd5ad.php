<?php $__env->startSection('title'); ?>Generate UML Model <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="coming_soon">
    <div class="container-fluid">
        <div class="d-flex flex-column justify-content-center align-items-center vh-100">
            <h1 class="text-center mb-5 text-white display-2">This feature will be available soon!</h1>
            <div class="card p-4 w-75">
                <div class="card-body">
                    <h1 class="card-title">Get Notified!</h1>
                    <h4>Be the first to explore our new features by submitting your email address. </h4>
                    <form method="POST" action="<?php echo e(url('coming-soon')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="email" class="form-control" placeholder="abc@email.com" aria-label="Email address" name="email_address" aria-describedby="button-addon2" required>
                        <input class="btn btn-primary w-100 mt-2" type="submit" id="button-addon2" value="Submit">
                    </form>
                    <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                        <strong><?php echo e(session('success')); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\us2uml\us2umlgm\resources\views/coming_soon.blade.php ENDPATH**/ ?>