<?php $__env->startSection('title'); ?> Update UML <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-4 vh-100">
    <div class="text-center">
        <h1>Update UML/GM Information</h1>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <img src="<?php echo e(asset('storage/images/'.$uml->image)); ?>" class="rounded">
            </div>
        </div>
        <div class="col-md-6">

            <form action="<?php echo e(route('add-uml.update', $uml->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                  <label for="project_title" class="form-label">Project Title</label>
                  <input type="text"
                    class="form-control" name="project_title" id="project_title" aria-describedby="helpId"
                    value="<?php echo e($uml->project_name); ?>">
                </div>

                <div class="mb-3">
                  <label for="new_uml_diagram" class="form-label">Choose file</label>
                  <input type="file" class="form-control" name="new_uml_diagram" id="new_uml_diagram"
                  accept="image/*" onChange="loadFile(event)">
                  <div id="fileHelpId" class="form-text">Image in PNG format is preferable</div>
                </div>

                <div class="text-center">
                    <img id="output" class="rounded mx-auto d-block mt-3 w-50 h-50" />
                </div>

                <div class="d-flex justify-content-between">
                    <div class="text-center">
                        <a class="btn btn-secondary" type="button" href="<?php echo e(route('submit.show', $uml->id)); ?>">Back</a>
                    </div>
                    <div class="text-center">
                        <input type="submit" class="btn btn-success" type="button">
                    </div>
                </div>
            </form>
        </div>
    </div>

</div>

<script type="text/javascript">
    var loadFile = function(event) {
        var reader = new FileReader();
        reader.onload = function(){
            var output = document.getElementById('output');
            output.src = reader.result;
        };
        reader.readAsDataURL(event.target.files[0]);
    };
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\us2uml\us2umlgm\resources\views/uml/update_uml.blade.php ENDPATH**/ ?>