<?php $__env->startSection('title'); ?> My Submission <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-md container-fluid py-5">
    <h1>User Stories and UML Diagram Submission</h1>
    <div class="table-responsive mt-3">
    <table class="table align-middle">
        <thead class="table-dark text-center">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Upload Time</th>
            <th scope="col">Project Name</th>
            <th scope="col">UML Diagram</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody class="text-center">
        <?php $__currentLoopData = $uml; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$uml): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e(++$key); ?></th>
            <td> <?php echo e($uml->created_at->diffForHumans()); ?> </td>
            <td> <?php echo e($uml->project_name); ?> </td>
            <td>
                <img class="img-fluid img-thumbnail" src="<?php echo e(asset('storage/images/'.$uml->image)); ?>" height="100px" width="100px">
            </td>
            <td>
                <div class="d-flex justify-content-between">
                    <a href="<?php echo e(route('submit.show' , $uml->id)); ?>" role="button" class="btn btn-primary">
                        <i class="bi bi-pencil bi-4x">EDIT</i>
                    </a>

                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal" data-item="<?php echo e($uml->id); ?>">
                       <i class="bi bi-trash-fill">DELETE</i>
                    </button>


                    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header bg-primary">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Delete <?php echo e($uml->project_name); ?></h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p>All information related to <?php echo e($uml->project_name); ?> will be deleted including all of the user stories.</p>
                                <p>Are you sure to <strong>delete</strong> <?php echo e($uml->project_name); ?>?</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <form action="<?php echo e(route('add-uml.destroy', $uml->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>

    <div class="text-center">
        <a href="<?php echo e(route('submit.create')); ?>" class="btn btn-primary">Make Another Submission</a>
    </div>
</div>

<script>
    $(document).on("click", ".btn-danger", function () {
       var itemid= $(this).attr('data-item');
       $("#lineitem").attr("href","/orders/line-item-delete/"+itemid)
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\us2uml\us2umlgm\resources\views/my_submission.blade.php ENDPATH**/ ?>