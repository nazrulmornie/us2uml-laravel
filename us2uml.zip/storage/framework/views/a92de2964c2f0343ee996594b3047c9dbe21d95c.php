<?php $__env->startSection('title'); ?> Update Profile <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="single-page-header">
    <div class="container w-100">
        <div class="row">
            <div class="col-md-12">
                <h2>Manage Profile</h2>
            </div>
        </div>
    </div>
</section>

<div class="container-fluid py-5">
    <div class="card mx-auto p-3" style="width: 65%">
        <div class="card-body">
            <div class="row d-flex justify-content-center">
                <div class="col-md-7 my-auto text-center">
                    <img src="<?php echo e(asset('storage/users/'.auth()->user()->avatar)); ?>" width="304" height="286" class="rounded-circle" style="object-fit: cover;">
                </div>
                <div class="col-md-5 my-auto justify-content-center">
                    <h1 class="text-center mb-4">Update Profile Image</h1>
                    <form method="POST" action="<?php echo e(route('user.update', auth()->user()->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        <div class="mb-3">
                          <label for="" class="form-label">Choose file</label>
                          <input type="file" class="form-control" accept="image/*" name="new_avatar" id="new_avatar" placeholder="" aria-describedby="fileHelpId">
                          <div id="fileHelpId" class="form-text">Upload your new profile image here</div>
                        </div>

                        <div class="text-end">
                            <input type="submit" role="button" class="btn btn-success">
                        </div>
                    </form>
                </div>
            </div>

            <hr>

            <h1 class="text-center my-4">User Information</h1>

            <form method="POST" action="<?php echo e(route('profile.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="card-body py-3 px-5">
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input class="form-control" type="text" id="name" name="name" value="<?php echo e(auth()->user()->name); ?>" autofocus="" required>
                    </div>

                    <div class="row">
                        <div class="mb-3 col-md-6">
                            <label for="phone_number" class="form-label">Phone Number</label>
                            <input class="form-control" type="text" name="phone_number" id="phone_number" placeholder="0123456789">
                        </div>
                        <div class="mb-3 col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input class="form-control" type="text" id="email" name="email" value="<?php echo e(auth()->user()->email); ?>" placeholder="john.doe@example.com">
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="mb-3">
                            <label for="about_me" class="form-label">About me</label>
                            <textarea class="form-control" name="about_me" id="about_me" rows="3" placeholder="Write something about yourself"></textarea>
                        </div>
                    </div>

                    <div class="row">
                        <div class="mb-3 col-md-7">
                            <div class="mb-3">
                                <label for="user_group" class="form-label">User Group</label>
                                <select class="form-select form-select-md" name="user_group" id="user_group">
                                    <option selected>Select one</option>
                                    <option value="">Students</option>
                                    <option value="">Industry Professionals</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3 col-md-5">
                            <label for="" class="form-label">Gender</label>
                            <select class="form-select form-select-md" name="" id="">
                                <option selected>Select one</option>
                                <option value="">Male</option>
                                <option value="">Female</option>
                                <option value="">Rather Not To Say</option>
                            </select>
                        </div>
                    </div>

                    <div class="mt-2 text-end">
                        <input type="submit" class="btn btn-primary" role="button" value="Save">
                    </div>
                </div>
            </form>
        </div>
    </div>

    

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\us2uml\us2umlgm\resources\views/update_profile.blade.php ENDPATH**/ ?>